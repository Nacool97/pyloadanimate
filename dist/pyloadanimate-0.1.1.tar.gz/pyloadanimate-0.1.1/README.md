# Python Loading Animation
This is a small library to add loading animation to your code.
Python load animation is written in python just to add a loading animation in you project
All you need to do is import the library call the function stat_animation() from loadanimation 
to start animation and stop_animation() to stop the animation